$('.img-parallax').each(function(){
  var img = $(this);
  var imgParent = $(this).parent();
  function parallaxImg () {
    var speed = img.data('speed');
    var imgY = imgParent.offset().top;
    var winY = $(this).scrollTop();
    var winH = $(this).height();
    var parentH = imgParent.innerHeight();


    // The next pixel to show on screen
    var winBottom = winY + winH;

    // If block is shown on screen
    if (winBottom > imgY && winY < imgY + parentH) {
      // Number of pixels shown after block appear
      var imgBottom = ((winBottom - imgY) * speed);
      // Max number of pixels until block disappear
      var imgTop = winH + parentH;
      // Porcentage between start showing until disappearing
      var imgPercent = ((imgBottom / imgTop) * 100) + (50 - (speed * 50));
    }
    img.css({
      top: imgPercent + '%',
      transform: 'translate(-50%, -' + imgPercent + '%)'
    });
  }
  $(document).on({
    scroll: function () {
      parallaxImg();
    }, ready: function () {
      parallaxImg();
    }
  });
});

const checkbox = document.querySelector('input');
const interval = setInterval(toggleHamburger, 1500);

function toggleHamburger() {
  checkbox.checked = !checkbox.checked;
}

document.addEventListener('mousemove', removeInterval);
document.addEventListener('click', removeInterval);

function removeInterval() {
  clearInterval(interval);
  document.removeEventListener('mousemove', removeInterval);
  document.removeEventListener('click', removeInterval);
}

function showNav() {
  var navList = document.getElementById("navList");
  if (navList.style.width === "100%") {
    navList.style.width = "0";
  } else {
    navList.style.width = "100%";
  }
}

function hideMenu() {
  var hideMenu = document.getElementById("menu");
  if (hideMenu.style.transform === "translateX(0px)") {
    hideMenu.style.transform = "translateX(1000px)";
  } else {
    hideMenu.style.transform = "translateX(0px)";
  }
}

$(document).ready(function(){
  $('#blockScroll').click(function(){
    $('body').toggleClass('noScroll');
  });
});

$(function(){

        var $window = $(window);
	var scrollTime = 1.2;
	var scrollDistance = 170;

	$window.on("mousewheel DOMMouseScroll", function(event){

		event.preventDefault();

		var delta = event.originalEvent.wheelDelta/100 || -event.originalEvent.detail/3;
		var scrollTop = $window.scrollTop();
		var finalScroll = scrollTop - parseInt(delta*scrollDistance);

		TweenMax.to($window, scrollTime, {
			scrollTo : { y: finalScroll, autoKill:true },
				ease: Power1.easeOut,
				overwrite: 5
			});

	});
});
