<!DOCTYPE html>
<html lang="en">
<head>

<title>Coffee</title>
<meta name="description" content="">
<meta name="author" content="">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


<link rel="shortcut icon" type="image/icon" href="images/cup-icon.png"/>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/owl.theme.css">
<link rel="stylesheet" href="css/owl.carousel.css">

<!-- Main css -->
<link rel="stylesheet" href="css/style.css">

<!-- Google Font -->
<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,600' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Lora:700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Berkshire+Swash" rel="stylesheet">   
<link href="https://fonts.googleapis.com/css?family=Concert+One|Lobster" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet"> 
<style type="text/css">
	#navbarr li a{
		color: #c0aa83;
		font-weight: 900;
		font-family: 'Montserrat', sans-serif;
		font-size: 16px;
		padding: 15px;
	}
	.navbar-header a{
		color: #c0aa83;
		font-weight: 900;
		font-family: 'Montserrat', sans-serif;
		font-size: 45px;
	}
</style>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">


<!-- =========================
     PRE LOADER       
============================== -->
<div  class="preloader">

	<div class="sk-spinner sk-spinner-pulse"></div>

</div>


<!-- =========================
    HOME SECTION   
============================== -->
<section id="home" class="parallax-section">
	<div class="container">
		<div class="row">
<div class="navbar navbar-transprent" role="navigation" id="sliderr">
	<div class="container">

		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" style="background-color:#242424">
				<span class="icon icon-bar" style="background-color: #c0aa83"></span>
				<span class="icon icon-bar" style="background-color: #c0aa83"></span>
				<span class="icon icon-bar" style="background-color: #c0aa83"></span>
			</button>
			<a href="#" class="navbar-brand">Quarter Coffee</a>
		</div>
		<div class="collapse navbar-collapse" id="navbarr">
			<ul class="nav navbar-nav navbar-right main-navigation">
				<li><a href="index.php" ><b>Home</b></a></li>
				<li><a href="about.php" >About</a></li>
				<li><a href="products.php" >Products</a></li>
				<li><a href="blog.php" >Blogs</a></li>
				<li><a href="contact.php?message=Leave a Comment" >Contact Us</a></li>
			</ul>
		</div>

	</div>
</div>
			<div class="col-md-offset-1 col-md-10 col-sm-12">

				<h3 class="wow bounceIn" data-wow-delay="0.9s">Hello! you are welcome to the</h3>
				<h1 class="wow fadeInUp" data-wow-delay="1.6s" style="font-size:6vw;font-family: 'Montserrat', sans-serif;">Quarter Coffee</h1>
				<a href="about.php" class="wow fadeInUp smoothScroll btn btn-default" data-wow-delay="2s" style="font-family: 'Montserrat', sans-serif;font-weight: 900">ABOUT US</a>
				<a href="products.php" id="products" class="wow fadeInUp smoothScroll btn btn-default" data-wow-delay="2s" style="font-family: 'Montserrat', sans-serif;font-weight: 900">OUR PRODUCTS</a>
			</div>

		</div>
	</div>
</section>


<!-- =========================
    OVERVIEW SECTION   
============================== -->
<section id="overview" class="parallax-section">
	<div class="container">
		<div class="row">

			<div class="col-md-6 col-sm-12">
				<img src="images/blog3-770x570.jpg" class="img-responsive" alt="Overview">
				<blockquote class="wow fadeInUp" data-wow-delay="1.9s"  style="text-align: justify;">Coffee can help people feel less tired/stress and increase energy levels. This is because it contains a stimulant called caffeine which is actually the most commonly consumed psychoactive substance in the world.</blockquote>
			</div>

			<div class="col-md-1"></div>

			<div class="wow fadeInUp col-md-4 col-sm-12" data-wow-delay="1s">
				<div class="overview-detail">
					<h2 style="font-family: 'Montserrat', sans-serif;font-weight: 900">About Coffee</h2>
					
					<p style="text-align: justify;">The rich and the finest coffee beans from our lands have been rich in taste & aroma. The overseas market is consuming all our finest beans and we want our consumers to taste the finest coffee.</p>
					<p style="text-align: justify;">Experience the ultimate taste of traditional filter coffee at its very best. Quarter coffee’s coffee is made from a blend of handpicked beans that are slow roasted to perfection, to give you an unmatched rich filter coffee experience.</p>
					<a href="contact.php?message=Leave a Comment" class="btn btn-default smoothScroll" style="font-family: 'Montserrat', sans-serif;font-weight: 900">Let us begin</a>
				</div>
			</div>

			<div class="col-md-1"></div>

		</div>
	</div>
</section>


<!-- =========================
    NEWSLETTER SECTION   
============================== -->
<section id="newsletter" class="parallax-section">
	<div class="container">
		<div class="row">

			<div class="wow fadeInUp col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10" data-wow-delay="0.9s">
				<h2 style="font-family: 'Montserrat', sans-serif;">Request Now</h2>
				
				<div class="newsletter_detail">
					<form action="mailer/index.php" method="GET" id="newsletter-signup">
						<div class="col-md-6 col-sm-6">
							<input name="name" type="text" class="form-control" id="name" placeholder="Name">
					  	</div>
						<div class="col-md-6 col-sm-6">
							<input name="email" type="email" class="form-control" id="email" placeholder="Email">
					  	</div>
						<div class="col-md-offset-3 col-md-6 col-sm-offset-2 col-sm-8">
							<input name="submit" type="submit" class="form-control" id="submit"  style="font-family: 'Montserrat', sans-serif;" value="SEND MESSAGE">
						</div>
				  	</form>
				</div>
			</div>

		</div>
	</div>
</section>


<!-- =========================
    TESTIMONIAL SECTION   
============================== -->
<section id="testimonial" class="parallax-section">
	<div class="container">
		<div class="row">

			<!-- Testimonial Owl Carousel section
			================================================== -->
			<div id="owl-testimonial" class="owl-carousel">

				<div class="item col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10 wow fadeInUp" data-wow-delay="0.6s">
					<i class="fa fa-quote-left"></i>
					<h3>We reveal the real taste of coffee.</h3>
					
				</div>

				<div class="item col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10 wow fadeInUp" data-wow-delay="0.6s">
					<i class="fa fa-quote-left"></i>
					<h3>Coffee! A cup of refreshing, brewed beverage.</h3>
					
				</div>

				<div class="item col-md-offset-2 col-md-8 col-sm-offset-1 col-sm-10 wow fadeInUp" data-wow-delay="0.6s">
					<i class="fa fa-quote-left"></i>
					<h3>Brewing the best cup of coffee to revitalize your mind.</h3>
					
				</div>

				
				
			</div>

		</div>
	</div>
</section>


<!-- =========================
    FOOTER SECTION   
============================== -->
<footer>
	<div class="container">
		<div class="row">

			<div class="wow fadeInUp col-md-4 col-sm-4" data-wow-delay="0.6s">
				<h2 style="font-family: 'Montserrat', sans-serif;">Contact Us</h2>
				<p>#1/3 Kuvempu Road, Kadirenahalli New Colony Banashankari 2nd Stage, Bengaluru 560070.</p>
			</div>

			<div class="wow fadeInUp col-md-5 col-sm-4"  data-wow-delay="0.9s">
				<h2 style="font-family: 'Montserrat', sans-serif;"></h2>
					
			</div>

			<div class="wow fadeInUp col-md-3 col-sm-4" data-wow-delay="1s">
				<h2 style="font-family: 'Montserrat', sans-serif;">Follow us</h2>
				<ul class="social-icon">
					<li><a href="#" class="fa fa-facebook wow fadeIn" data-wow-delay="1s"></a></li>
					<li><a href="#" class="fa fa-twitter wow fadeInUp" data-wow-delay="1.3s"></a></li>
					<li><a href="#" class="fa fa-youtube wow fadeIn" data-wow-delay="1.6s"></a></li>
					<li><a href="#" class="fa fa-instagram wow fadeInUp" data-wow-delay="1.9s"></a></li>
					<li><a href="#" class="fa fa-google-plus wow fadeIn" data-wow-delay="2s"></a></li>
				</ul>
			</div>

			<div class="clearfix"></div>

			<div class="col-md-12 col-sm-12">
				<p class="copyright-text">Copyright &copy; 2018 Quarter Coffee 
                    
			</div>
			
		</div>
	</div>
</footer>

<!-- =========================
     SCRIPTS   
============================== -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.parallax.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>